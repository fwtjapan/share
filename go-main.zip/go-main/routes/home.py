from flask import Blueprint, render_template

home_bp = Blueprint('home', __name__)


@home_bp.route('/')
def index():
    """分潤計劃首頁"""
    return render_template('home.html')
